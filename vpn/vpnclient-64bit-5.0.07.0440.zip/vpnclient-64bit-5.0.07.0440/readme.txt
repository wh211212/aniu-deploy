# cisco vpn install options
Firest:
  install winfix.exe then restart system
Second:
  install dneupdate64.exe,then install vpnclient_setup Windows Installer
Last:
  modify regedit, press windows + R export run box 
#
??-??-regedit????HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\CVirtA??DisplayName,??????

?"@oem16.inf,%CVirtA_Desc%;Cisco Systems VPN Adapter for 64-bitWindows�???"Cisco Systems VPN Adapter for 64-bit Windows�
